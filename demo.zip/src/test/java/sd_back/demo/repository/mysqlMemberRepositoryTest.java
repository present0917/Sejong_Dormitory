package sd_back.demo.repository;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


class mysqlMemberRepositoryTest {

    @Test
    public void test(){
        
    }
}